# Projeto Receita

## Integrantes

* Débora Peres
* Eduarda Nogueira
* Kauane Izidoro

> Páginas obrigatórias

* Home
* Quem somos
* Doces
* Salgados
* Contato
* Localização
